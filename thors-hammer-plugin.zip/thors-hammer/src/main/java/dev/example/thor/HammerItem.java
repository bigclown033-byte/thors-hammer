package dev.example.thor;

import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

final class HammerItem {

    private final NamespacedKey key;

    HammerItem(Plugin plugin) {
        this.key = new NamespacedKey(plugin, "thors_hammer");
    }

    ItemStack create() {
        ItemStack item = new ItemStack(Material.MACE);
        item.editMeta(meta -> {
            meta.customName(Component.text("Thor's Hammer", NamedTextColor.GOLD, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(
                    line("/ability 1: Lightning strike", NamedTextColor.YELLOW),
                    line("/ability 2: Skyward launch + lightning dash", NamedTextColor.YELLOW)));
            meta.setUnbreakable(true);
            meta.setEnchantmentGlintOverride(true);
            meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        });
        return item;
    }

    boolean isHammer(ItemStack item) {
        if (item == null || item.getType() != Material.MACE || !item.hasItemMeta()) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }

    private static Component line(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }
}
