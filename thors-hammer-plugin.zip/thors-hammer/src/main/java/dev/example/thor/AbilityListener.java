package dev.example.thor;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerQuitEvent;

final class AbilityListener implements Listener {

    private final AbilityManager abilities;

    AbilityListener(AbilityManager abilities) {
        this.abilities = abilities;
    }

    /** The skyward launch shouldn't punish you with fall damage on landing. */
    @EventHandler(ignoreCancelled = true)
    public void onFall(EntityDamageEvent event) {
        if (event.getCause() == EntityDamageEvent.DamageCause.FALL
                && event.getEntity() instanceof Player player
                && abilities.consumeFallProtection(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        abilities.clear(event.getPlayer().getUniqueId());
    }
}
