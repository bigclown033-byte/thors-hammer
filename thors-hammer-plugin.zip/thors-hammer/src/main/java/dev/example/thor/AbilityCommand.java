package dev.example.thor;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

final class AbilityCommand implements TabExecutor {

    private final AbilityManager abilities;
    private final HammerItem hammer;

    AbilityCommand(AbilityManager abilities, HammerItem hammer) {
        this.abilities = abilities;
        this.hammer = hammer;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "ability" -> handleAbility(sender, args);
            case "thorshammer" -> handleGive(sender, args);
            default -> { return false; }
        }
        return true;
    }

    private void handleAbility(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use abilities.");
            return;
        }
        if (args.length != 1 || !(args[0].equals("1") || args[0].equals("2"))) {
            player.sendMessage(Component.text("Usage: /ability <1|2>", NamedTextColor.RED));
            return;
        }
        if (args[0].equals("1")) {
            abilities.useLightning(player);
        } else {
            abilities.useLift(player);
        }
    }

    private void handleGive(CommandSender sender, String[] args) {
        Player target;
        if (args.length > 0) {
            target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage(Component.text("Player not found: " + args[0], NamedTextColor.RED));
                return;
            }
        } else if (sender instanceof Player self) {
            target = self;
        } else {
            sender.sendMessage("Specify a player: /thorshammer <player>");
            return;
        }

        Map<Integer, ItemStack> leftover = target.getInventory().addItem(hammer.create());
        leftover.values().forEach(item -> target.getWorld().dropItemNaturally(target.getLocation(), item));
        sender.sendMessage(Component.text("Gave Thor's Hammer to " + target.getName() + ".", NamedTextColor.GREEN));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) {
            return List.of();
        }
        String prefix = args[0].toLowerCase(Locale.ROOT);
        if (command.getName().equalsIgnoreCase("ability")) {
            return List.of("1", "2").stream().filter(s -> s.startsWith(prefix)).toList();
        }
        return Bukkit.getOnlinePlayers().stream()
                .map(Player::getName)
                .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(prefix))
                .toList();
    }
}
