package dev.example.thor;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class ThorsHammerPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();

        HammerItem hammer = new HammerItem(this);
        AbilityManager abilities = new AbilityManager(this, hammer);
        AbilityCommand commands = new AbilityCommand(abilities, hammer);

        for (String name : new String[] {"ability", "thorshammer"}) {
            PluginCommand command = getCommand(name);
            if (command != null) {
                command.setExecutor(commands);
                command.setTabCompleter(commands);
            }
        }

        getServer().getPluginManager().registerEvents(new AbilityListener(abilities), this);
    }
}
