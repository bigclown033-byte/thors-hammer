package dev.example.thor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

final class AbilityManager {

    /** Right after launching the player may still read as "on ground"; ignore that briefly. */
    private static final long LIFT_OFF_GRACE_MS = 400;

    private static final class AirState {
        final long launchedAt;
        final long expiresAt;
        boolean dashUsed;

        AirState(long launchedAt, long expiresAt) {
            this.launchedAt = launchedAt;
            this.expiresAt = expiresAt;
        }
    }

    private final JavaPlugin plugin;
    private final HammerItem hammer;
    private final Map<UUID, Long> lightningReadyAt = new HashMap<>();
    private final Map<UUID, Long> launchReadyAt = new HashMap<>();
    private final Map<UUID, AirState> airborne = new HashMap<>();

    AbilityManager(JavaPlugin plugin, HammerItem hammer) {
        this.plugin = plugin;
        this.hammer = hammer;
    }

    // ---- Ability 1: lightning strike -------------------------------------------------

    void useLightning(Player player) {
        if (!requireHammer(player)) {
            return;
        }
        long now = System.currentTimeMillis();
        if (onCooldown(player, lightningReadyAt, now)) {
            return;
        }

        FileConfiguration cfg = plugin.getConfig();
        LivingEntity target = findTarget(player, cfg.getDouble("lightning.range", 30));
        if (target == null) {
            msg(player, "No target in sight.", NamedTextColor.RED);
            return;
        }

        target.getWorld().strikeLightningEffect(target.getLocation());
        target.damage(cfg.getDouble("lightning.damage", 8.0), player);

        long cooldownMs = (long) (cfg.getDouble("lightning.cooldown-seconds", 20) * 1000);
        lightningReadyAt.put(player.getUniqueId(), now + cooldownMs);
        msg(player, "Smitten!", NamedTextColor.GOLD);
    }

    private LivingEntity findTarget(Player player, double range) {
        World world = player.getWorld();
        Location eye = player.getEyeLocation();
        Vector direction = eye.getDirection();

        RayTraceResult entityHit = world.rayTraceEntities(eye, direction, range, 0.6, e ->
                e instanceof LivingEntity
                        && !e.equals(player)
                        && !(e instanceof ArmorStand)
                        && !(e instanceof Player other && other.getGameMode() == GameMode.SPECTATOR));
        if (entityHit == null || !(entityHit.getHitEntity() instanceof LivingEntity target)) {
            return null;
        }

        // A solid block in the way blocks the strike.
        RayTraceResult blockHit = world.rayTraceBlocks(eye, direction, range, FluidCollisionMode.NEVER, true);
        if (blockHit != null
                && blockHit.getHitPosition().distance(eye.toVector())
                        < entityHit.getHitPosition().distance(eye.toVector())) {
            return null;
        }
        return target;
    }

    // ---- Ability 2: skyward launch, then lightning dash ------------------------------

    void useLift(Player player) {
        if (!requireHammer(player)) {
            return;
        }
        long now = System.currentTimeMillis();
        UUID id = player.getUniqueId();

        AirState state = airborne.get(id);
        if (state != null
                && (now > state.expiresAt
                        || (now - state.launchedAt > LIFT_OFF_GRACE_MS && player.isOnGround()))) {
            airborne.remove(id);
            state = null;
        }

        if (state != null) {
            dash(player, state, now);
            return;
        }
        launch(player, now);
    }

    private void launch(Player player, long now) {
        if (onCooldown(player, launchReadyAt, now)) {
            return;
        }
        FileConfiguration cfg = plugin.getConfig();

        Vector current = player.getVelocity();
        player.setVelocity(new Vector(current.getX(), cfg.getDouble("launch.velocity", 1.19), current.getZ()));
        player.setFallDistance(0f);

        long windowMs = (long) (cfg.getDouble("launch.dash-window-seconds", 10) * 1000);
        airborne.put(player.getUniqueId(), new AirState(now, now + windowMs));

        long cooldownMs = (long) (cfg.getDouble("launch.cooldown-seconds", 20) * 1000);
        launchReadyAt.put(player.getUniqueId(), now + cooldownMs);

        sparks(player, 1.2f);
        msg(player, "Skyward! Use /ability 2 again in the air to lightning dash.", NamedTextColor.GOLD);
    }

    private void dash(Player player, AirState state, long now) {
        if (now - state.launchedAt < LIFT_OFF_GRACE_MS) {
            return;
        }
        if (state.dashUsed) {
            msg(player, "You already used your lightning dash this flight.", NamedTextColor.RED);
            return;
        }
        state.dashUsed = true;

        double strength = plugin.getConfig().getDouble("launch.dash-strength", 1.8);
        player.setVelocity(player.getLocation().getDirection().normalize().multiply(strength));

        sparks(player, 1.6f);
        msg(player, "Lightning dash!", NamedTextColor.YELLOW);
    }

    /**
     * Called when a launched player takes fall damage. Returns true if the damage should be
     * cancelled, and ends the flight.
     */
    boolean consumeFallProtection(Player player) {
        AirState state = airborne.remove(player.getUniqueId());
        return state != null && System.currentTimeMillis() <= state.expiresAt;
    }

    void clear(UUID id) {
        airborne.remove(id);
        lightningReadyAt.remove(id);
        launchReadyAt.remove(id);
    }

    // ---- Helpers ---------------------------------------------------------------------

    private boolean requireHammer(Player player) {
        if (!hammer.isHammer(player.getInventory().getItemInMainHand())) {
            msg(player, "You must be holding Thor's Hammer.", NamedTextColor.RED);
            return false;
        }
        return true;
    }

    private boolean onCooldown(Player player, Map<UUID, Long> readyAt, long now) {
        long ready = readyAt.getOrDefault(player.getUniqueId(), 0L);
        if (now < ready) {
            long seconds = (long) Math.ceil((ready - now) / 1000.0);
            msg(player, "Ability on cooldown: " + seconds + "s", NamedTextColor.RED);
            return true;
        }
        return false;
    }

    private void sparks(Player player, float pitch) {
        Location loc = player.getLocation().add(0, 1, 0);
        player.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 40, 0.4, 0.6, 0.4, 0.15);
        player.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.6f, pitch);
    }

    private static void msg(Player player, String text, NamedTextColor color) {
        player.sendMessage(Component.text(text, color));
    }
}
