# Thor's Hammer (Paper 1.21.11)

Build (JDK 21 + Maven):

    mvn package

Jar: target/thors-hammer-1.0.0.jar -> copy into your server's plugins/ folder and restart.

Get the hammer: /thorshammer [player]  (op, permission thorshammer.give)

While holding it:
  /ability 1  Lightning strike on the entity you're looking at (4 hearts, 20s cooldown)
  /ability 2  Launch ~8 blocks up; run it again in the air for a lightning dash

Tune everything in plugins/ThorsHammer/config.yml.
